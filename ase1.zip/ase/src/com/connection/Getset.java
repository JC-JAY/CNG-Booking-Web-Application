package com.connection;

public class Getset {
	static String id, name, mobile_number;

	public static String getId() {
		return id;
	}

	public static void setId(String id) {
		Getset.id = id;
	}

	public static String getName() {
		return name;
	}

	public static void setName(String name) {
		Getset.name = name;
	}

	public static String getmobile_number() {
		return mobile_number;
	}

	public static void setMobile(String mobile) {
		Getset.mobile_number = mobile_number;
	}
}
